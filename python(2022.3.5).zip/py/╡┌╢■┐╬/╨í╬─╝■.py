for i in range(2,9):
    print(i)
print("第二个")    
for i in range(1,100,4):
    print(i)


    
