bingo = '1'
answer = input('请输入一个数字')
while True:
    if answer == bingo:
        break
    answer = input('哎呦，错了，需要输入正确才能退出 ')
print('哎呦，这都被你猜对了')
