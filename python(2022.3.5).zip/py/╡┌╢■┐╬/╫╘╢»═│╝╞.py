print("请输入一个分数，系统会进行自动评分(在0—100之间）")
a=1
while a==1:
    score=int(input('请输入您要计算的值:'))
    if 100>=score>=80:
        print("A")
    if 80>score>=60:
        print("B")
    if 60>score>=40:
        print("C")
    if 40>score>=20:
        print("D")
    if 20>score>=0:
        print("E")
    if score<0 or score>101:
        print("输入错误!")

