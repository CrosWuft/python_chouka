i='吴铸杰是帅哥'
b=input("请输入我最想听的一句话")

while True:
    if b==i:
        break
    b=input("请重新输入")
print("不愧是你，厉害，这都知道")
