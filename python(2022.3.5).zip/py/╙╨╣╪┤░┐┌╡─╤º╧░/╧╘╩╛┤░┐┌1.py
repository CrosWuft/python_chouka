import tkinter as dx1   #导入窗口模块

#dx以及大写字母是可更改的
A = dx1.Tk()       #定义A为窗口名称
A.title('我的小程序')     #窗口主题
A.geometry('500x300')        #设置窗口大小

B = dx1.Label(A,                #定义窗口内的东西
              text='欢迎进入',             # 标题的文字
              font=("Arial",40),# 字体和字体大小('Arial'为字体；'40'为字体大小)
              width=15,height=2)     # 标题长宽
B.pack()                #完成定义

#设置内容（前面部分为显示内容，后面为显示位置）
dx1.Label(A, text='1号选项').place(x=50,y=150)
dx1.Label(A, text='2号选项').place(x=50,y=190)
A.mainloop()
