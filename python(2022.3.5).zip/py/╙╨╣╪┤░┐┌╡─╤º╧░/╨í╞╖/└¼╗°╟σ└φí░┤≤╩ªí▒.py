import tkinter as dx1   

def hs1():
    C = dx1.Tk()     
    C.title('错误')     
    C.geometry('200x100')       
    D= dx1.Label(C,              
              text='未检测到垃圾',            
              font=("Arial",20),
              width=15,height=2)
    D.pack()
def hs2():
    C = dx1.Tk()     
    C.title('成功')     
    C.geometry('200x100')       
    D= dx1.Label(C,              
              text='已成功清除垃圾',            
              font=("Arial",20),
              width=15,height=2)
    D.pack()
    
A = dx1.Tk()      
A.title('清理大师')     
A.geometry('500x300')       
B = dx1.Label(A,             
              text='点击下方按钮清理',             
              font=("Arial",40),
              width=15,height=2) 
B.pack()
log1 = dx1.Button(A, text='普通清理', command=hs1)
log1.place(x=140, y=230)
log1 = dx1.Button(A, text='强力清理', command=hs2)
log1.place(x=250, y=230)  
A.mainloop()
