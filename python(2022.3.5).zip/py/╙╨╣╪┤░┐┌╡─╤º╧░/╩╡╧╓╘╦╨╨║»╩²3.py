#注：dx,log,hs以及大写字母是可更改的

#导入窗口模块,令dx1为此模块的参数
import tkinter as dx1   


#设置窗口
A = dx1.Tk()       #定义A为窗口名称（"TK"为模块代表）
A.title('登陆系统')     #窗口主题
A.geometry('500x300')        #设置窗口大小



#定义窗口内的东西
B = dx1.Label(A,                #定义窗口内的东西
              text='欢迎进入',             # 标题的文字
              font=("Arial",40),# 字体和字体大小('Arial'为字体；'40'为字体大小)
              width=15,height=2)     # 标题长宽（'width'为长,'height'为高）
B.pack()                #完成定义（固定窗口位置）



#设置内容（前面部分为显示内容，后面为显示位置）
dx1.Label(A, text='账号').place(x=50,y=150)
dx1.Label(A, text='密码').place(x=50,y=190)


#设置填写窗口(三句话一句不能少)
dx3 = dx1.StringVar()       #设置一个可填写的窗口
dx4 = dx1.Entry(A, textvariable=dx3)    #定义窗口的作用（'Entry'为输入）
dx4.place(x=160, y=150)     #设置此窗口的位置(x为距竖轴距离,y为距横轴距离)
#设置第二个窗口
dx5 = dx1.StringVar()
dx6= dx1.Entry(A, textvariable=dx5, show='*')
dx6.place(x=160, y=190)


#定义一些要用到的函数
def hs1():
    print("登录失败，未检测到该账户")


#设置点击性按钮
log1 = dx1.Button(A, text='登录', command=hs1)
#定义窗口的作用（'Button'为点击）command表示为运行某个函数
log1.place(x=170, y=230)   #设置此窗口的位置(x为距竖轴距离,y为距横轴距离)

A.mainloop()
