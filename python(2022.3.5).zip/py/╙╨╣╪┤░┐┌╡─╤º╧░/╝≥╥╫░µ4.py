import tkinter as dx1   

A = dx1.Tk()      
A.title('登陆系统')     
A.geometry('500x300')       
B = dx1.Label(A,             
              text='欢迎进入',             
              font=("Arial",40),
              width=15,height=2)     
B.pack()                
dx1.Label(A, text='账号').place(x=50,y=150)
dx1.Label(A, text='密码').place(x=50,y=190)
dx3 = dx1.StringVar()      
dx4 = dx1.Entry(A, textvariable=dx3)   
dx4.place(x=160, y=150)    
dx5 = dx1.StringVar()
dx6= dx1.Entry(A, textvariable=dx5, show='*')
dx6.place(x=160, y=190)
def hs1():
    C = dx1.Tk()     
    C.title('错误')     
    C.geometry('200x100')       
    D= dx1.Label(C,              
              text='未检测到该账户',            
              font=("Arial",20),
              width=15,height=2)
    D.pack()
log1 = dx1.Button(A, text='登录', command=hs1)
log1.place(x=200, y=230)   
A.mainloop()


