while True:
    index = input(">>")
    if not index.isdigit():
        print("请输入数字！")
