import time
while True:
    import random
    a=random.randint (1,15)
    print (a)
    time.sleep(1)
