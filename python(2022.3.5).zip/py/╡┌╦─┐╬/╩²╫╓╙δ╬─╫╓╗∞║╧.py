a='你好' 

b=input('请输入你的年龄')
c=int(b)
print(a)
print("你的年龄为{0}".format(c))
