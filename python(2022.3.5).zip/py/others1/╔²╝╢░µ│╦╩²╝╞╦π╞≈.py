q=1
while q==1:
    a=int(input('请输入乘数'))
    b=int(input('请输入被乘数'))
    c=a*b
    print(c)
