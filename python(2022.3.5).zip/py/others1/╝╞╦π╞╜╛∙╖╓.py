print('请分别输入四次成绩，系统将自动为您统计')
q=1
while q==1:
    a=int(input('请输入第一次成绩'))
    b=int(input('请输入第二次成绩'))
    c=int(input('请输入第三次成绩'))
    d=int(input('请输入第四次成绩'))
    e=(a+b+c+d)/4
    print(e)
