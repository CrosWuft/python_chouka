while True:
    print(input().strip("吗？？")+"!")
