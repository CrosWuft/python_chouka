q=2
while q!= 1:
    a=int(input('将你心里想的数×10再加上20 '))
    b=(a-20)/10
    print('你心里想的数是.......')
    print(b)
