print(".........micosft.............")
temp=input("不妨猜一下我心里想的是哪个数字")
guess=int(temp)
if guess ==8:
    print("卧槽，这你都知道")
else:
    print (" 哼，这都猜不中")
print("哼，游戏结束，不玩了")

