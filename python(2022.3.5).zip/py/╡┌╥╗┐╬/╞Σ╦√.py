temp=input("输入1来运行,其他无效")
guess=int(temp)
while guess==1:
    print("sb")
