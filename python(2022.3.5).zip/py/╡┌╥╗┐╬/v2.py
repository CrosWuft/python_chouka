print(".........micosft.............")
temp=input("不妨猜一下我心里想的是哪个数字")
guess=int(temp)
while guess !=8:
    temp=input("哎呀，猜错了，请重新输入吧")
    guess=int(temp)
    if guess ==8:
        print("卧槽，这你都知道")
    else:
        if guess>8:
            print (" 哥，大了大了")
        else:
            if guess <8:   
                print("哥，小了小了")
print ("恭喜猜中，但游戏结束啦，不玩啦")

