import random
b=input("输入“1”来进行抽奖")
c=int(b)
while c==1:
    a=random.randint (1,10)
    if a==10:
        print("恭喜中大奖--100万")
    if a==9:
        print("恭喜中二等奖--10元")
    if a<8:
        print("很遗憾，您没有中奖")
    if a!=0:
        b=input("按下转行键来进行抽奖")
    
