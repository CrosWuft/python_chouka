import random
import time

print("幸运大抽奖，分为两个奖励： 一等奖（一百万）  二等奖（十元）")
b=input("输入“1”来进行抽奖")
c=int(b)
while c==1:
    print(".......到底有没有中奖呢?........")
    time.sleep(1.8)
    a=random.randint (1,10)
    if a==10:
         print("恭喜中大奖--100万")
    if a==9:
        print("恭喜中二等奖--10元")
    if a<8:
        print("很遗憾，您没有中奖")
    if a<8:
        input("按下转行键来进行抽奖")
    if a>8:
        print("MD，你运气居然那么好，不敢跟你玩了，我怕还吃亏")
        break
        
