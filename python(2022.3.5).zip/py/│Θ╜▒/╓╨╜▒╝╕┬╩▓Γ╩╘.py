import random

k=1
print("幸运大抽奖，分为三个奖励： 一等奖（一百万）  二等奖（一百元）  三等奖（十元） ")
input("按下转行键来进行抽奖")
while True:
    print(".......到底有没有中奖呢?........")
    a=random.randint (-980,20)
    if a==20:
         print("恭喜中大奖--100万")
         print("中奖概率为.....分之一")
         print(k)
         input("按下转行键来再次进行抽奖")
         k=1
    if 20>a>17:
        print("恭喜中二等奖--100元")
        print("中奖概率为.....分之一")
        print(k)
        input("按下转行键来再次进行抽奖")
        k=1
    if 14<a<18:
        print("恭喜中三等奖--10元")
        print("中奖概率为.....分之一")
        print(k)
        input("按下转行键来再次进行抽奖")
        k=1
    if a<15:
        print("很遗憾，您没有中奖")
        k=k+1




