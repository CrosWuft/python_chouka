import time
while True:
    import random
    a=random.randint (1,10)
    time.sleep(2)
    if a==10:
        print("恭喜中大奖--100万")
    if a==9:
        print("恭喜中二等奖--10元")
    if a<8:
        print("很遗憾，您没有中奖")
