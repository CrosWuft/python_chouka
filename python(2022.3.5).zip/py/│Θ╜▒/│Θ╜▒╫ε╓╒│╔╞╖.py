import random
import time

print("幸运大抽奖，分为三个奖励： 一等奖（一百万）  二等奖（一百元）  三等奖（十元） ")
input("按下转行键来进行抽奖")
while True:
    print(".......到底有没有中奖呢?........")
    time.sleep(1.8)
    a=random.randint (1,20)
    if a==20:
         print("恭喜中大奖--100万")
    if a==19:
        print("恭喜中二等奖--100元")
    if 16<a<19:
        print("恭喜中三等奖--10元")
        print("我居然亏了，再来")
        input("按下转行键来再次进行抽奖")
    if a<17:
        print("很遗憾，您没有中奖")
        input("按下转行键来再次进行抽奖")
    if a>18:
        print("MD，你运气居然那么好，不敢跟你玩了，我怕还吃亏")
        break
