import random
import time

print (".................速算答题..................")
x=0
n=0
m=0

difficult1=input("请输入你想要的模式，输入除1外任意数直接开始，输入1进入高级选项")
difficult2=int(difficult1)
if difficult2 ==1:
    z=input("请输入你想答的题数(输入0为随机题数)")
    y=int(z)
    w=input('请输入最小加数')
    t=int(w)
    h=input("请输入最大加数")
    u=int(h)
    if y==0:
        y=random.randint(1,45)
    while (x<y):
        x=x+1
        a=random.randint (t,u)
        b=random.randint (t,u)
        print ("请问")
        print (a)
        print ("加")
        print (b)
        c=input("请输入等于几：")
        d=int(c)
        e=a+b
        if e==d:
            print ("真棒，你答对了，继续答题吧")
            print("现在你做的题目数 以及 还要做的题目数为;")
            n=n+1
        else:
            print ("糟糕，你答错了，正确答案是......")
            print (e)
            m=m+1
            print('现在你做的题目数 以及 还要做的题目数为;')
        print (x,y-x)
        print("....................................................................")
        time.sleep(0.8)
    print("你做对的题数为")
    print(n)
    print("你做错的题数为")
    print(m)
    if y>=n>=0.8*y:
        print("你的评分为：     A")
    if 0.8*y>n>=0.6*y:
        print("你的评分为：     B")
    if 0.6*y>n>=0.4*y:
        print("你的评分为：     C")
    if 0.4*y>n>=0.2*y:
        print("你的评分为：     D")
    if 0.2*y>n>=0:
        print("你的评分为：     E")
if difficult2!=1:
    while (x<20):
        x=x+1
        a=random.randint (1,10)
        b=random.randint (1,10)
        print ("请问")
        print (a)
        print ("加")
        print (b)
        c=input("请输入等于几：")
        d=int(c)
        e=a+b
        if e==d:
             print ("真棒，你答对了，继续答题吧")
             print("现在你做的题目数 以及 还要做的题目数为;")
             n=n+1
        else:
             print ("糟糕，你答错了，正确答案是......")
             print (e)
             m=m+1
             print('现在你做的题目数 以及 还要做的题目数为;')
        print (x,20-x)
        print("....................................................................")
        time.sleep(0.8)
    print("你做对的题数为")
    print(n)
    print("你做错的题数为")
    print(m)
    if 20>=n>=0.8*20:
        print("你的评分为：     A")
    if 0.8*20>n>=0.6*20:
        print("你的评分为：     B")
    if 0.6*20>n>=0.4*20:
        print("你的评分为：     C")
    if 0.4*20>n>=0.2*20:
        print("你的评分为：     D")
    if 0.2*20>n>=0:
        print("你的评分为：     E")
