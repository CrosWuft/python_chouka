import random
import time

print (".................速算100题口算答题..................")
x=0
n=0
m=0
while (x<100):
    x=x+1
    a=random.randint (1,10)
    b=random.randint (1,10)
    print ("请问")
    print (a)
    print ("加")
    print (b)
    c=input("请输入等于几：")
    d=int(c)
    e=a+b
    if e==d:
        print ("真棒，你答对了，继续答题吧；现在你做的题目数为")
        n=n+1
    else:
        print ("糟糕，你答错了，正确答案是......")
        print (e)
        m=m+1
        print('现在你做的题目数为;')
    print (x)
    print("....................................................................")
    time.sleep(1)
print("你做对的题数为")
print(n)
print("你做错的题数为")
print(m)

