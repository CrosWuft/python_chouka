import random
import time

print ("数学简单口算答题")
while True:
    a=random.randint (1,10)
    b=random.randint (1,10)
    print ("请问")
    print (a)
    print ("加")
    print (b)
    c=input("请输入等于几")
    d=int(c)
    e=a+b
    if e==d:
        print ("真棒，你答对了，继续答题吧")
    else:
        print ("糟糕，你答错了，正确答案是......")
        print (e)
    time.sleep(1)
