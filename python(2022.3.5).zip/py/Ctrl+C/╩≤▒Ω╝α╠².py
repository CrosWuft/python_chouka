from pynput.mouse import Listener


def on_move(x, y):
    print(f"鼠标移动到: ({x}, {y})")


def on_click(x, y, button, is_press):
    print(f"鼠标{button}键在({x}, {y})处{'按下' if is_press else '松开'}")


def on_scroll(x, y, dx, dy):
    if dx:
        print(f"滑轮在({x}, {y})处向{'右' if dx > 0 else '左'}滑")
    else:
        print(f"滑轮在({x}, {y})处向{'下' if dy > 0 else '上'}滑")


with Listener(
    # 上面函数名不能变，记得对应
    on_move=on_move,
    on_click=on_click,
    on_scroll=on_scroll
) as listener:
    listener.join()
"""
鼠标移动到: (1090, 369)
鼠标移动到: (1090, 368)
鼠标移动到: (1090, 368)
鼠标移动到: (1090, 367)
鼠标Button.left键在(1090, 367)处按下
鼠标Button.left键在(1090, 367)处松开
滑轮在(1090, 367)处向上滑
"""
