from pynput.keyboard import Key, Listener


# 此时的Listener是从keyboard里面导入的

def on_press(key):
    # 当按下esc，结束监听
    if key == Key.esc:
        print(f"你按下了esc，监听结束")
        return False
    print(f"你按下了{key}键")


def on_release(key):
    print(f"你松开了{key}键")


with Listener(on_press=on_press, on_release=on_release) as listener:
    listener.join()
"""
你按下了'a'键
你松开了'a'键
你按下了Key.shift键
你松开了Key.shift键
你按下了Key.right键
你松开了Key.right键
你按下了Key.down键
你松开了Key.down键
你按下了esc，监听结束
"""
