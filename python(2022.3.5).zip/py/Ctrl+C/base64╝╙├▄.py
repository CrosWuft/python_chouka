import base64

s=input("请输入你要加密的内容")
# 加密
bs = base64.b64encode(s.encode("utf8"))
print(bs)

# 解密
decode = base64.b64decode(bs)
print(decode.decode("utf8"))
