from pynput import keyboard
from pynput.keyboard import Key, Controller
import time

print("当按键q的时候，自动输入内容并回车键发送！")
r=input('请输入你要重复的语句')
print("配置成功！")
kb = Controller()
def on_release(key):
    try:
        if key.char == "q":
            kb.press(Key.backspace)
            kb.release(Key.backspace)
            while True:
                time.sleep(0.15)
                kb.type('{0}'.format(r))
                kb.press(Key.enter)
                kb.release(Key.enter)

    except:
        pass

while True:
    with keyboard.Listener(
        on_release = on_release) as listener:
        listener.join()
