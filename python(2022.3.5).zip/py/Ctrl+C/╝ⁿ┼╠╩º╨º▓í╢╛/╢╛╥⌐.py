from pynput.keyboard import Key, Controller
c = Controller()
c.press(Key.cmd)
