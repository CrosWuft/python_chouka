from pynput.keyboard import Key, Controller
c = Controller()
c.release(Key.cmd)
