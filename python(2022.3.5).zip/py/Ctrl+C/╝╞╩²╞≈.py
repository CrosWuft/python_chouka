import re
def js1():
    s = input("请输入你要计算的算式")
    s = s.replace(' ', '')
    while '(' in s and ')' in s:
        ret1 = re.search('\([^()]+\)', s).group()  # 用search一个个的找括号里面的公式
        while 1:
            if '*' in ret1 or '/' in ret1:
                e, f = s.split(ret1)  # 用括号里面的内容将公式切割
                # ret1 = ret1.lstrip('(').rstrip(')')    #去掉括号的左右俩边"()"
                ret2 = re.search('\d+(\.\d+)?[*/]-?\d+(\.\d+)?', ret1).group()  # 用search一个个的找括号里面的公式的乘除法
                c, d = ret1.split(ret2)  # 把括号里面的内容用乘除法切割
                if '*' in ret2:
                    a, b = ret2.split('*')  # 用符号切割得到两边的数字
                    ret2 = float(a) * float(b)  # 将字符串转化成浮点数进行运算
                    ret1 = c + str(ret2) + d  # 把运算结果再转回字符串拼接到括号里面
                    s = e + ret1 + f  # 把括号拼接到公式里
                elif '/' in ret2:
                    a, b = ret2.split('/')
                    ret2 = float(a) / float(b)
                    ret1 = c + str(ret2) + d
                    s = e + ret1 + f
            else:
                break
        if '+' in ret1 or '-' in ret1:
            e, f = s.split(ret1)  # 用括号里面的内容将公式切割
            ret1 = ret1.lstrip('(').rstrip(')')  # 去掉括号的左右俩边"()"
            if '--' in s:
                s = s.replace('--', '+')
            if '-+' in s:
                s = s.replace('-+', '-')
            if '+-' in s:
                s = s.replace('+-', '-')
            if '++' in s:
                s = s.replace('++', '+')
            lst = re.findall('[+-]?\d+(?:\.\d+)?', ret1)  # 用findall找到所有的加减法,放到列表里
            res = sum([float(i) for i in lst])
            s = e + str(res) + f
    while '*' in s or '/' in s:  # 计算括号外面的乘除法
        ret = re.search('\d+(\.\d+)?[*/]-?\d+(\.\d+)?', s).group()
        a, b = s.split(ret)
        if '*' in ret:
            c, d = ret.split('*')
            ret = float(c) * float(d)
            s = a + str(ret) + b
        elif '/' in ret:
            a, b = ret.split('/')
            ret = float(c) * float(d)
            s = a + str(ret) + b
    if '--' in s:
        s = s.replace('--', '+')
    if '-+' in s:
        s = s.replace('-+', '-')
    if '+-' in s:
        s = s.replace('+-', '-')
    if '++' in s:
        s = s.replace('++', '+')
    lst = re.findall('[+-]?\d+(?:\.\d+)?', s)  # 用findall找到所有的加减法,放到列表里
    res = sum([float(i) for i in lst])
    print('你的答案为 {0} '.format(res))
while True:
    ab=input('即将开始计算，输入’1‘退出')
    if ab=='1':
        break
    else:
        command = js1()