#模块组
import pynput 
from pynput.keyboard import Key, Controller
import time

#获取操作对象
c = Controller()
ctr = pynput.mouse.Controller()
a=0
c.press(Key.cmd)#

#运行组
while a==0:
#键盘
    time.sleep(0)#
    c.press(Key.cmd)
    c.press('r')
    c.release('r')
    c.release(Key.cmd)
    c.type("cmd")
    c.press(Key.enter)
    c.release(Key.enter)
#鼠标
    time.sleep(0)#
    ctr.move(0, 180)
    ctr.move(180,0)

