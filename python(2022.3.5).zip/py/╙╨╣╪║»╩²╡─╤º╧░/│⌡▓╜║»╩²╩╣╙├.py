#[例子一]调用函数方法：  a('任何文字')
def a(name):
    print(name + '我爱你')
#[例子二]调用函数方法：  b()
def b():
    print("你好")
    print("很高兴见到你")
#[例子三]调用函数方法：  c(数字，数字)   或 c("中文","中文")
def c(n1,n2):
    d= n1 + n2
    print(d)
#[例子四]调用函数方法：  e(数字，数字)   或 e("中文","中文")
def e(m1,m2):
    return m1 + m2
